﻿using Gol.Data.Repository;
using Gol.Domain.Entities;

namespace Webgol.Data.Repository
{
    public interface IUserTokenRepository : IRepository<Usertoken>
    {
        Usertoken GetUserToken(string UserID);
    }
}

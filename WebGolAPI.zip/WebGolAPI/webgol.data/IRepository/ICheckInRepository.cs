﻿using Gol.Data.Repository;
using Gol.Domain.Entities;

namespace Webgol.Data.Repository
{

    public interface ICheckInRepository : IRepository<Checkin>
    {
        Checkin GetCheckinUserID(string UserID);
    }
}

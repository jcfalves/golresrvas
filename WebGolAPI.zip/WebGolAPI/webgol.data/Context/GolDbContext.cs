﻿using Gol.Domain.Entities;
using Microsoft.EntityFrameworkCore;


namespace Gol.Data.Context
{
#pragma warning disable CS1591
    public class GolDbContext : DbContext
    {
        public GolDbContext(DbContextOptions<GolDbContext> options)
            : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
        }

        public DbSet<Usertoken> Usertokens { get; set; }
        public DbSet<Checkin> Checkins { get; set; }
    }

#pragma warning restore CS1591
}

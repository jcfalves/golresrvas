﻿namespace Webgol.Data.Repository
{
    public class GenericResult
    {
        public bool Succeeded { get; set; }
        public string Message { get; set; }
        public int Id { get; set; }
        public string Control { get; set; }
    }
}

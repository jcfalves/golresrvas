﻿using Gol.Data.Context;
using Gol.Domain.Entities;
using System.Linq;

namespace Webgol.Data.Repository
{
    public class UserTokenRepository : Repository<Usertoken>, IUserTokenRepository
    {
        public UserTokenRepository(GolDbContext context) : base(context)
        { }
        private GolDbContext _appContext => (GolDbContext)_context;

        public Usertoken GetUserToken(string UserID)
        {
            var userToken = _appContext.Usertokens
            .Where(r => r.UserID == UserID)
             .FirstOrDefault();
            return userToken;
        }

    }
}

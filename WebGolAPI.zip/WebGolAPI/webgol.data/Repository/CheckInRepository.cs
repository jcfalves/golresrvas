﻿using Gol.Data.Context;
using Gol.Domain.Entities;
using System.Linq;

namespace Webgol.Data.Repository
{
    public class CheckInRepository : Repository<Checkin>, ICheckInRepository
    {
        public CheckInRepository(GolDbContext context) : base(context)
        { }
        private GolDbContext _appContext => (GolDbContext)_context;

        public Checkin GetCheckinUserID(string UserID)
        {
            var checkin = _appContext.Checkins
             .Where(r => r.nome ==  UserID)
             .FirstOrDefault();
            return checkin;
        }
    }
}

﻿using Gol.Domain.Entities.Errors;
using System;
using System.Collections.Generic;
using System.Text;

namespace Gol.Domain.Entities.Listas
{
    public class Tuplas<T> where T : class
    {
        #region construtores

        /// <summary>
        /// construtor da classe Tuplas
        /// </summary>
        public Tuplas()
        {

            // bloco de contrução de objetos
            TratarRetorno = new Retorno();
        }

        #endregion

        #region propriedades

        public IEnumerable<T> Retorno { get; set; }



        public Retorno TratarRetorno { get; set; }

        #endregion
    }
}

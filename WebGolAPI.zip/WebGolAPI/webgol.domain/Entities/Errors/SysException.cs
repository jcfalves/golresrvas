﻿namespace Gol.Domain.Entities.Errors
{
    public class Retorno
    {
        #region construtores

        public Retorno()
        {
            // indica sucesso
            Status = EStatus.OK;
           // RetornoHttp = "200";
        }

        #endregion

        #region propriedades

        public EStatus Status { get; set; }
       // public int Status_Error { get; set; }
        public string RetornoHttp { get; set; }
        public string MensagemExcecao { get; set; }
        public string MensagemSucesso { get; set; }
        public object  DadosRetorno { get; set; }
        public string MensagemRetornoVazio { get; set; }
        #endregion
    }

    public enum EStatus
    {
        //Sucesso = 1,
        //Alerta = 2,
        //Erro = 3 ,
        OK = 200  ,
        Created_Criado  =  201  ,    
        Accepted_Aceito = 202 ,
        NoContent = 204 ,     
        Precondition_Failed = 412  ,    
        Unauthorized = 401 ,
        Internal_server = 500
    }
}
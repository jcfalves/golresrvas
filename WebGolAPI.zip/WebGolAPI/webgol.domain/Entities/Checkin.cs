﻿using System;

namespace Gol.Domain.Entities
{
#pragma warning disable CS1591
    public partial class Checkin
    {
        public Checkin()
        {
        }
        public int id { get; set; }
        public string nome { get; set; }
        public DateTime datapartida { get; set; }
        public string horapartida { get; set; }
        public string origem { get; set; }
        public string destino { get; set; }
    }
#pragma warning restore CS1591
}
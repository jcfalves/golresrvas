﻿namespace Gol.Domain.Entities
{
#pragma warning disable CS1591
    public partial class Usertoken
    {
        public Usertoken()
        {
        }

        public Usertoken(string userID)
        {
            UserID = userID;
        }
        public int Id { get; set; }
        public string UserID { get; set; }
        public string AccessKey { get; set; }
    }
#pragma warning restore CS1591
}

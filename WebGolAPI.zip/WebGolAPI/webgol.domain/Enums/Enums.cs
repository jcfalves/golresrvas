﻿namespace Gol.Domain.Enums
{
    public enum EIngresso
    {
        Tradicional = 0,
        Agendado = 1,
        Enem = 2,
        Transferencia = 3,
        Portador = 4,
        Pos = 5
    }

    public enum ETipoEscola
    {
        Publica = 0,
        Privada = 1
    }

    public enum ESexo
    {
        M = 0,
        F = 1,
        N = 2
    }
}

﻿using AutoMapper;
using Gol.Domain.Entities;

namespace WebGol.ViewModel
{
    public class AutoMapperProfile : Profile
    {
        public AutoMapperProfile()
        {
            CreateMap<Checkin, CheckInViewModel>()
            .ReverseMap();
        }

    }
}

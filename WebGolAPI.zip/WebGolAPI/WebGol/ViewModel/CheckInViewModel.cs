﻿using System;

namespace WebGol.ViewModel
{
    public class CheckInViewModel
    {
        public int Chk_Id { get; set; }
        public string nome { get; set; }
        public DateTime datapartida { get; set; }
        public string horapartida { get; set; }
        public string origem { get; set; }
        public string destino { get; set; }
    }
}

﻿using AutoMapper;
using Gol.Data.Context;
using Gol.Domain.Entities;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using Webgol.Data.Repository;
using WebGol.ViewModel;

namespace Gol.Controllers
{
#pragma warning disable CS1591

    [ApiController]
    [Produces("application/json")]
    [Route("api/v1/[controller]")]
    public class CheckInController : ControllerBase
    {
        #region atributos
        protected readonly GolDbContext DbContext;
        private readonly ICheckInRepository _checkInRepository;

        #endregion

        #region construtores DisponibilidadeMatriculasController

        /// <summary>
        /// construtor da classe 
        /// </summary>
        /// <param name="logger"></param>
        /// <param name="dbContext"></param>
        public CheckInController( GolDbContext dbContext,
            ICheckInRepository checkInRepository)
        {
                     DbContext = dbContext;
            _checkInRepository = checkInRepository;
        }
        #endregion
        #region métodos


        [Authorize("Bearer")]
        [HttpGet("checkinall")]
        [ProducesResponseType(200)]
        public IActionResult Getcontrapartidas()
        {
            var checkIn = _checkInRepository.GetAll();
            if (checkIn == null)
                return NotFound("Não localizado");
            return Ok(checkIn);
        }

        [Authorize("Bearer")]
        [HttpGet("{id}")]
        [ProducesResponseType(200)]
        [ProducesResponseType(403)]
        [ProducesResponseType(404)]
        public IActionResult GetCheckInById(string id)
        {
            Checkin checkin = new Checkin();
            int Int = int.Parse(id);

            checkin = _checkInRepository.Get(Int);
            if (checkin == null)
            {
                return NotFound();
            }
            return Ok(checkin);
        }


        [Authorize("Bearer")]
        [HttpDelete("{id}")]
        [ProducesResponseType(200)]
        [ProducesResponseType(400)]
        [ProducesResponseType(403)]
        [ProducesResponseType(404)]
        public IActionResult DeleteCheckIn(string id)
        {
            IActionResult _result = new ObjectResult(false);
            GenericResult _removeResult = null;

            int Int = int.Parse(id);
            try
            {
                Checkin _checkin = _checkInRepository.Get(Int);
                this._checkInRepository.Remove(_checkin);
                this._checkInRepository.Commit();

                _removeResult = new GenericResult()
                {
                    Id = _checkin.id,
                    Succeeded = true,
                    Message = "CheckIn removido."
                };
            }
            catch (Exception ex)
            {
                _removeResult = new GenericResult()
                {
                    Succeeded = false,
                    Message = ex.Message
                };
            }
            _result = new ObjectResult(_removeResult);
            return _result;
        }

        [Authorize("Bearer")]
        [HttpPost("checkin")]
        [ProducesResponseType(201)]
        [ProducesResponseType(400)]
        public IActionResult CreateCheckin([FromBody] CheckInViewModel check)
        {
            IActionResult _result = new ObjectResult(false);
            GenericResult _removeResult = null;
            try
            {
                if (ModelState.IsValid)
                {
                    if (check == null)
                        return BadRequest($"{nameof(check)} não pode ser nulo");

                    Checkin checkin = Mapper.Map<Checkin>(check);
                    this._checkInRepository.Add(checkin);
                    this._checkInRepository.Commit();

                    int idd = checkin.id;
                    _removeResult = new GenericResult()
                    {
                        Id = checkin.id,
                        Succeeded = true,
                        Message = "Checkin incluído.",
                    };
                }
            }
            catch (Exception ex)
            {
                _removeResult = new GenericResult()
                {
                    Succeeded = false,
                    Message = ex.Message
                };
            }
            _result = new ObjectResult(_removeResult);
            return _result;
        }

        [Authorize("Bearer")]
        [HttpPut("{id}")]
        [ProducesResponseType(204)]
        [ProducesResponseType(400)]
        [ProducesResponseType(403)]
        [ProducesResponseType(404)]
        public IActionResult UpdateCheckIn(string id, [FromBody] CheckInViewModel checkin)
        {
            IActionResult _result = new ObjectResult(false);
            GenericResult _removeResult = null;
            try
            {
                if (ModelState.IsValid)
                {
                    if (checkin == null)
                        return BadRequest($"{nameof(checkin)} não pode ser nulo");

                    if (Convert.ToInt16(id) == 0)
                        return BadRequest("Parametro não localizado!.");

                    int Int = int.Parse(id);
                    Checkin _Checkin = _checkInRepository.Get(Int);
                    if (_Checkin == null)
                        return NotFound(id);

                    Mapper.Map<CheckInViewModel, Checkin>(checkin, _Checkin);
                    _checkInRepository.Update(_Checkin);
                    this._checkInRepository.Commit();
                    _removeResult = new GenericResult()
                    {
                        Id = _Checkin.id,
                        Succeeded = true,
                        Message = "CheckIn modificado."
                    };
                }
            }
            catch (Exception ex)
            {
                _removeResult = new GenericResult()
                {
                    Succeeded = false,
                    Message = ex.Message
                };
            }
            _result = new ObjectResult(_removeResult);
            return _result;
        }
        #endregion

    }

#pragma warning restore CS1591
}  
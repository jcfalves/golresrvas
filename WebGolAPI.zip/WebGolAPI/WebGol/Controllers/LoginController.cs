﻿using Gol.Data.Context;
using Gol.Domain.Entities;
using Gol.Token;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Principal;
using Webgol.Data.Repository;

namespace Gol.Controllers
{
#pragma warning disable CS1591
    [Route("api/[controller]")]
    public class LoginController : Controller
    {
        protected readonly GolDbContext DbContext;
        private readonly IUserTokenRepository _userTokenRepository;

        public LoginController(GolDbContext dbContext,
                               IUserTokenRepository userTokenRepository)
        {
            DbContext = dbContext;
            _userTokenRepository = userTokenRepository;
        }


        [AllowAnonymous]
        [HttpPost]
        public object Post(
            [FromBody]Usertoken usuario,
            [FromServices]SigningConfigurations signingConfigurations,
            [FromServices]TokenConfigurations tokenConfigurations)
        {
            try
            {
                Usertoken usertoken = null;

                bool credenciaisValidas = false;
                if (usuario != null && !String.IsNullOrWhiteSpace(usuario.UserID))
                {
                    usertoken = _userTokenRepository.GetUserToken(usuario.UserID);
                    credenciaisValidas = (usuario.UserID == usertoken.UserID &&
                        usuario.AccessKey == usertoken.AccessKey);
                }

                if (credenciaisValidas)
                {
                    ClaimsIdentity identity = new ClaimsIdentity(
                        new GenericIdentity(usuario.UserID, "Login"),
                        new[] {
                        new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString("N")),
                        new Claim(JwtRegisteredClaimNames.UniqueName, usuario.UserID)
                        }
                    );

                    DateTime dataCriacao = DateTime.Now;
                    DateTime dataExpiracao = dataCriacao +
                        TimeSpan.FromSeconds(tokenConfigurations.Seconds);

                    var handler = new JwtSecurityTokenHandler();
                    var securityToken = handler.CreateToken(new SecurityTokenDescriptor
                    {
                        Issuer = tokenConfigurations.Issuer,
                        Audience = tokenConfigurations.Audience,
                        SigningCredentials = signingConfigurations.SigningCredentials,
                        Subject = identity,
                        NotBefore = dataCriacao,
                        Expires = dataExpiracao
                    });
                    var token = handler.WriteToken(securityToken);

                    return new
                    {
                        authenticated = true,
                        created = dataCriacao.ToString("yyyy-MM-dd HH:mm:ss"),
                        expiration = dataExpiracao.ToString("yyyy-MM-dd HH:mm:ss"),
                        accessToken = token,
                        message = "OK"
                    };
                }
                else
                {
                    return new ContentResult
                    {
                        Content = "Falha no Token ",
                        StatusCode = (int)System.Net.HttpStatusCode.Unauthorized
                    };
                }
            }
            catch (Exception e)
            {
                return new ContentResult
                {
                    Content = e.Message,
                    StatusCode = (int)System.Net.HttpStatusCode.InternalServerError
                };
            }
        }
    }
#pragma warning restore CS1591
}
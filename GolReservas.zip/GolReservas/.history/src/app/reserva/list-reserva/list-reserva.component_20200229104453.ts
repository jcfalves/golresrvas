import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-list-reserva',
  templateUrl: './list-reserva.component.html',
  styleUrls: ['./list-reserva.component.css']
})
export class ListReservaComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ReservaService } from 'src/app/shared/api.reserva';
import { Reserva } from 'src/app/shared/model/reserva';


@Component({
  selector: 'app-list-reserva',
  templateUrl: './list-reserva.component.html',
  styleUrls: ['./list-reserva.component.css']
})
export class ListReservaComponent implements OnInit {

  reserva: Reserva = {id: null, nome: '', datapartida: null, horapartida: '', origem: '', destino: ''};

  isLoadingResults = true;

  constructor(private route: ActivatedRoute, private api: ReservaService,
              private router: Router) { }

  ngOnInit() {
    this.getReservaDetails(this.route.snapshot.params['id']);
  }

  getReservaDetails(id: any) {
    this.api.getReserva(id)
      .subscribe((data: any) => {
        this.reserva = data;
        console.log(this.reserva);
        this.isLoadingResults = false;
      });
  }

  deleteReserva(id: any) {
    this.isLoadingResults = true;
    this.api.deleteReserva(id)
      .subscribe(res => {
          this.isLoadingResults = false;
          this.router.navigate(['/reserva']);
        }, (err) => {
          console.log(err);
          this.isLoadingResults = false;
        }
      );
  }
}

import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormControl, FormGroupDirective, FormBuilder, FormGroup, NgForm, Validators } from '@angular/forms';
import { ErrorStateMatcher } from '@angular/material/core';
import { ReservaService } from 'src/app/shared/api.reserva';

export class MyErrorStateMatcher implements ErrorStateMatcher {
  isErrorState(control: FormControl | null, form: FormGroupDirective | NgForm | null): boolean {
    const isSubmitted = form && form.submitted;
    return !!(control && control.invalid && (control.dirty || control.touched || isSubmitted));
  }
}

@Component({
  selector: 'app-edit-reserva',
  templateUrl: './edit-reserva.component.html',
  styleUrls: ['./edit-reserva.component.css']
})
export class EditReservaComponent implements OnInit {

  reservaForm: FormGroup;
  id = '';
  nome = '';
  datapartida = '';
  horapartida = '';
  origem = '';
  destino = '';
  isLoadingResults = false;
  matcher = new MyErrorStateMatcher();

  constructor(private router: Router, private route: ActivatedRoute,
              private api: ReservaService, private formBuilder: FormBuilder) { }

  ngOnInit() {
    this.getProduct(this.route.snapshot.params['id']);
    this.reservaForm = this.formBuilder.group({
      'nome' : [null, Validators.required],
      'datapartida' : [null, Validators.required],
      'horapartida' : [null, Validators.required],
      'origem' : [null, Validators.required],
      'destino' : [null, Validators.required]
    });
  }

  getProduct(id: any) {
    this.api.getReserva(id).subscribe((data: any) => {
      this.id = data.id;
      this.reservaForm.setValue({
        nome: data.nome,
        datapartida: data.datapartida,
        horapartida: data.horapartida,
        origem: data.origem,
        destino: data.destino
      });
    });
  }

  onFormSubmit() {
    this.isLoadingResults = true;
    this.api.updateReserva(this.id, this.reservaForm.value)
      .subscribe((res: any) => {
          const id = res._id;
          this.isLoadingResults = false;
          this.router.navigate(['/reserva-details', id]);
        }, (err: any) => {
          console.log(err);
          this.isLoadingResults = false;
        }
      );
  }

  reservaDetails() {
    this.router.navigate(['/reserva-details', this.id]);
  }
}

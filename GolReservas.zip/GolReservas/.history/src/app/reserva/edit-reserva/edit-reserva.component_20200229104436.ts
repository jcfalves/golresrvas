import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-reserva',
  templateUrl: './edit-reserva.component.html',
  styleUrls: ['./edit-reserva.component.css']
})
export class EditReservaComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

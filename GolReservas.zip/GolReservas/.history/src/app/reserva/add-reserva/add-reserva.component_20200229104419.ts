import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-reserva',
  templateUrl: './add-reserva.component.html',
  styleUrls: ['./add-reserva.component.css']
})
export class AddReservaComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

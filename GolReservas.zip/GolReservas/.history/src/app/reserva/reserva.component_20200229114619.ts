import { Component, OnInit } from '@angular/core';
import { Product } from '../shared/model/product';
import { Router } from '@angular/router';
import { ReservaService } from '../shared/api.reserva';
import { Reserva } from '../shared/model/reserva';

@Component({
  selector: 'app-reserva',
  templateUrl: './reserva.component.html',
  styleUrls: ['./reserva.component.css']
})
export class ReservaComponent implements OnInit {

  displayedColumns: string[] = ['nome', 'origem'];
  data: Reserva[] = [];
  isLoadingResults = true;

  constructor(private api: ReservaService, private router: Router) { }

  ngOnInit() {
      this.api.getReservas()
      .subscribe( data => {
        this.data = data;
      });

    // this.api.getReservas()
    //   .subscribe((res: any) => {
    //     this.data = res;
    //     console.log(this.data);
    //     this.isLoadingResults = false;
    //   }, err => {
    //     console.log(err);
    //     this.isLoadingResults = false;
    //   });
  }
}

import { Injectable } from '@angular/core';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { Observable, Subject, throwError } from 'rxjs';
import { mergeMap, switchMap, catchError } from 'rxjs/operators';


@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private fb: FormBuilder, private http: HttpClient) { }

  // readonly BaseURI = 'http://localhost:54140/api';
  // readonly BaseURI = 'http://localhost:50453/api/Login';
  private isRefreshingLogin: boolean;
  public apiVersion: string = '1';
  public appVersion: string = '0.0.1';
  private taskPauser: Subject<any>;

  headers = {
    headers: new HttpHeaders({
        'Content-Type': 'application/json'
    })
  }

  

  formModel = this.fb.group({
    UserName: ['', Validators.required],
    Email: ['', Validators.email],
    FullName: [''],
    Passwords: this.fb.group({
      Password: ['', [Validators.required, Validators.minLength(4)]],
      ConfirmPassword: ['', Validators.required]
    }, { validator: this.comparePasswords })

  });

  comparePasswords(fb: FormGroup) {
    let confirmPswrdCtrl = fb.get('ConfirmPassword');
    //passwordMismatch
    //confirmPswrdCtrl.errors={passwordMismatch:true}
    if (confirmPswrdCtrl.errors == null || 'passwordMismatch' in confirmPswrdCtrl.errors) {
      if (fb.get('Password').value != confirmPswrdCtrl.value)
        confirmPswrdCtrl.setErrors({ passwordMismatch: true });
      else
        confirmPswrdCtrl.setErrors(null);
    }
  }

  register() {
    var body = {
      UserName: this.formModel.value.UserName,
      Email: this.formModel.value.Email,
      FullName: this.formModel.value.FullName,
      Password: this.formModel.value.Passwords.Password
    };
    return this.http.post(this.BaseURI + '/ApplicationUser/Register', body);
  }

  login(formData) {
  
    const httpOptions = {
      headers: new HttpHeaders({'Content-Type': 'application/json'})
    }

    return this.http.post(this.BaseURI + '/Login', formData, httpOptions);
    
  }

  getUserProfile() {
    return this.http.get(this.BaseURI + '/UserProfile');
  }

  
  // getUpdatePessoaEndpoint<T>(userObject: any, userId?: string): Observable<T> {
  //   let endpointUrl = `${'this._pessoaUrl'}/${userId}`;

  //   return this.http.put<T>(endpointUrl, JSON.stringify(userObject), 
  //         this.getRequestHeaders()).pipe<T>(
  //       catchError(error => {
  //           return this.handleError(error, () => this.getUpdatePessoaEndpoint(userObject, userId));
  //       }));  
  // }

  public getRequestHeaders(): { headers: HttpHeaders | { [header: string]: string | string[]; } } {
    let headers = new HttpHeaders({
      'Authorization': 'Bearer ' + localStorage.getItem('accessToken'),  
      'Content-Type': 'application/json',
      'Accept': `application/vnd.iman.v${this.apiVersion}+json, application/json, text/plain, */*`,
      'App-Version': this.appVersion
    });

    return { headers: headers };
  }

  // getNewPessoaTipoEndpoint<T>(userObject: any): Observable<T> {

  //   return this.http.post<T>(this.pessoaTipoUrl, JSON.stringify(userObject), this.getRequestHeaders()).pipe<T>(
  //     catchError(error => {
  //       return this.handleError(error, () => this.getNewPessoaTipoEndpoint(userObject));
  //     }));
  // }


  // getNewPessoaTipoEndpoint<T>(userObject: any): Observable<T> {

  //   return this.http.post<T>(this.pessoaTipoUrl, JSON.stringify(userObject), this.getRequestHeaders()).pipe<T>(
  //     catchError(error => {
  //       return this.handleError(error, () => this.getNewPessoaTipoEndpoint(userObject));
  //     }));
  // }

  // getUpdatePessoaTipoEndpoint<T>(userObject: any, userId?: string): Observable<T> {
  //   //let endpointUrl = userId ? `${this.pessoaTipoUrl}/${userId}` : this.currentUserUrl;
  //   let endpointUrl = `${this.pessoaTipoUrl}/${userId}`;
  //   return this.http.put<T>(endpointUrl, JSON.stringify(userObject), this.getRequestHeaders()).pipe<T>(
  //     catchError(error => {
  //       return this.handleError(error, () => this.getUpdatePessoaTipoEndpoint(userObject, userId));
  //     }));
  // }
  // getDeletePessoaTipoEndpoint<T>(userId: string): Observable<T> {
  //   let endpointUrl = `${this.pessoaTipoUrl}/${userId}`;

  //   return this.http.delete<T>(endpointUrl, this.getRequestHeaders()).pipe<T>(
  //     catchError(error => {
  //       return this.handleError(error, () => this.getDeletePessoaTipoEndpoint(userId));
  //     }));
  // }


  // getPessoaTipoEndpoint<T>(page?: number, pageSize?: number): Observable<T> {
  //   let endpointUrl = page && pageSize ? `${this.pessoaTipoUrl}/${page}/${pageSize}` : this.pessoaTipoUrl;

  //   return this.http.get<T>(endpointUrl, this.getRequestHeaders()).pipe<T>(
  //     catchError(error => {
  //       return this.handleError(error, () => this.getPessoaTipoEndpoint(page, pageSize));
  //     }));
  // }

  // protected getRequestHeaders(): { headers: HttpHeaders | { [header: string]: string | string[]; } } {
  //   let headers = new HttpHeaders({
  //     'Authorization': 'Bearer ' + this.authService.accessToken,
  //     'Content-Type': 'application/json',
  //     'Accept': `application/vnd.iman.v${EndpointFactory.apiVersion}+json, application/json, text/plain, */*`,
  //     'App-Version': ConfigurationService.appVersion
  //   });

  //   return { headers: headers };
  // }


  private resumeTasks(continueOp: boolean) {
    setTimeout(() => {
      if (this.taskPauser) {
        this.taskPauser.next(continueOp);
        this.taskPauser.complete();
        this.taskPauser = null;
      }
    });
  }
  private handleError(error, continuation: () => Observable<any>) {

    if (error.status == 401) {
      // if (this.isRefreshingLogin) {
      //   return this.pauseTask(continuation);
      // }

      this.isRefreshingLogin = true;

      // return this.authService.refreshLogin().pipe(
      //   mergeMap(data => {
      //     this.isRefreshingLogin = false;
      //     this.resumeTasks(true);

      //     return continuation();
      //   }),
      //   catchError(refreshLoginError => {
      //     this.isRefreshingLogin = false;
      //     this.resumeTasks(false);

      //     if (refreshLoginError.status == 401 || (refreshLoginError.url && refreshLoginError.url.toLowerCase().includes(this.loginUrl.toLowerCase()))) {
      //       //this.authService.reLogin();
      //       return throwError('session expired');
      //     }
      //     else {
      //       return throwError(refreshLoginError || 'server error');
      //     }
      //   }));
    }
  }
}

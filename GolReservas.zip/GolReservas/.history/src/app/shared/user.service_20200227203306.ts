import { Injectable } from '@angular/core';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { HttpClient, HttpHeaders } from "@angular/common/http";

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private fb: FormBuilder, private http: HttpClient) { }
  //readonly BaseURI = 'http://localhost:54277/api';
  readonly BaseURI = 'http://localhost:50453/api';

  formModel = this.fb.group({
    Id: [''],
    UserID: ['', Validators.required],
    Email: ['', Validators.email],
    FullName: [''],
    AccessKeys: this.fb.group({
      AccessKey: ['', [Validators.required, Validators.minLength(4)]],
      ConfirmAccessKey: ['', Validators.required]
    }, { validator: this.compareAccessKeys })

  });

  compareAccessKeys(fb: FormGroup) {
    let confirmPswrdCtrl = fb.get('ConfirmAccessKey');
    //AccessKeyMismatch
    //confirmPswrdCtrl.errors={AccessKeyMismatch:true}
    if (confirmPswrdCtrl.errors == null || 'AccessKeyMismatch' in confirmPswrdCtrl.errors) {
      if (fb.get('AccessKey').value != confirmPswrdCtrl.value)
        confirmPswrdCtrl.setErrors({ AccessKeyMismatch: true });
      else
        confirmPswrdCtrl.setErrors(null);
    }
  }

  register() {
    var body = {
      UserID: this.formModel.value.UserID,
      Email: this.formModel.value.Email,
      FullName: this.formModel.value.FullName,
      AccessKey: this.formModel.value.AccessKeys.AccessKey
    };
    return this.http.post(this.BaseURI + '/ApplicationUser/Register', body);
  }

  login(formData) {
    return this.http.post(this.BaseURI + '/Login', formData);
  }

  getUserProfile() {
    return this.http.get(this.BaseURI + '/UserProfile');
  }
}

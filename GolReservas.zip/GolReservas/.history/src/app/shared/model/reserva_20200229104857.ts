export class Reserva {
    Id: number;
    nome: string;
    datapartida: string;
    horapartida: string;
    origem: string;
    destino: string;
  }
  
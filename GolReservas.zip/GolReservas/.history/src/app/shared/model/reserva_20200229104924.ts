export class Reserva {
    id: number;
    nome: string;
    datapartida: string;
    horapartida: string;
    origem: string;
    destino: string;
  }

import { Injectable } from '@angular/core';
import { Observable, of, throwError } from 'rxjs';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { catchError, tap, map } from 'rxjs/operators';
import { Reserva } from './model/reserva';

const httpOptions = {
  headers: new HttpHeaders({'Content-Type': 'application/json'})
};
// const apiUrl = 'http://localhost:50453/api/v1/CheckIn/checkinall';

const apiUrl = 'http://localhost:50453/api/v1/CheckIn/';
            //    http://localhost:50453/api/v1/CheckIn/checkin/2
@Injectable({
  providedIn: 'root'
})
export class ReservaService {

  constructor(private http: HttpClient) { }

  getReservas(): Observable<Reserva[]> {
    const url = `${apiUrl}${'checkinall'}`;
    return this.http.get<Reserva[]>(apiUrl)
      .pipe(
        tap(reserva => console.log('fetched reservas')),
        catchError(this.handleError('getReservas', []))
      );
  }

  getReserva(id: number): Observable<Reserva> {
    const url = `${apiUrl}/${id}`;
    return this.http.get<Reserva>(url).pipe(
      tap(_ => console.log(`fetched reserva id=${id}`)),
      catchError(this.handleError<Reserva>(`getReserva id=${id}`))
    );
  }

  addReserva(reserva: Reserva): Observable<Reserva> {
    return this.http.post<Reserva>(apiUrl, reserva, httpOptions).pipe(
      tap((res: any) => console.log(`added reserva w/ id=${res._id}`)),
      catchError(this.handleError<Reserva>('addReserva'))
    );
  }

  updateReserva(id: any, reserva: Reserva): Observable<any> {
    const url = `${apiUrl}/${id}`;
    return this.http.put(url, reserva, httpOptions).pipe(
      tap(_ => console.log(`updated reserva id=${id}`)),
      catchError(this.handleError<any>('updateReserva'))
    );
  }

  deleteReserva(id: any): Observable<Reserva> {
    const url = `${apiUrl}/${id}`;
    return this.http.delete<Reserva>(url, httpOptions).pipe(
      tap(_ => console.log(`deleted reserva id=${id}`)),
      catchError(this.handleError<Reserva>('deleteReserva'))
    );
  }

  private handleError<T>(operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {

      // TODO: send the error to remote logging infrastructure
      console.error(error); // log to console instead

      // Let the app keep running by returning an empty result.
      return of(result as T);
    };
  }
}

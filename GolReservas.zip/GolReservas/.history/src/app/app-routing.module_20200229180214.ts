import { AuthGuard } from './auth/auth.guard';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UserComponent } from './user/user.component';
import { RegistrationComponent } from './user/registration/registration.component';
import { LoginComponent } from './user/login/login.component';
import { HomeComponent } from './home/home.component';
import { ProductsComponent } from './products/products.component';
import { ProductDetailComponent } from './products/product-detail/product-detail.component';
import { ProductAddComponent } from './products/product-add/product-add.component';
import { ProductEditComponent } from './products/product-edit/product-edit.component';
import { ListReservaComponent } from './reserva/list-reserva/list-reserva.component';
import { EditReservaComponent } from './reserva/edit-reserva/edit-reserva.component';
import { ReservaComponent } from './reserva/reserva.component';
import { AddReservaComponent } from './reserva/add-reserva/add-reserva.component';

const routes: Routes = [
  {path: '', redirectTo: '/user/login', pathMatch: 'full'},
  {
    path: 'user', component: UserComponent,
    children: [
      { path: 'registration', component: RegistrationComponent },
      { path: 'login', component: LoginComponent }
    ]
  },
  {
    path: 'reserva-details/:id',
    component: ListReservaComponent,
    data: { title: 'Detalhes Reservas', canActivate: [AuthGuard] }
  },
  {
    path: 'reserva-add',
    component: AddReservaComponent,
    data: { title: 'Add Reserva', canActivate: [AuthGuard] }
  },
  {
    path: 'reserva-edit/:id',
    component: EditReservaComponent,
    data: { title: 'Edit Reserva',
     canActivate: [AuthGuard] }
  },
  { path: 'reserva',
    component: ReservaComponent, canActivate: [AuthGuard]
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
